#ifndef RUNCHECKPOINT_H
#define RUNCHECKPOINT_H

#include <string>
#include <vector>

// Memento
class RunCheckpoint {
private:
    int stage;
    std::vector<std::string> records;

public:
    RunCheckpoint(int stage, std::vector<std::string> records);
    int getStage() const;
    std::vector<std::string> getRecords() const;
};

#endif