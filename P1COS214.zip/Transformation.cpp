#include "Transformation.h"

// ---------------------------------------------------------------------
// Transformation (abstract base)
// ---------------------------------------------------------------------
Transformation::Transformation(std::string name) : name(name) {}

std::string Transformation::getName() {
    return name;
}

Transformation::~Transformation() {}

// ---------------------------------------------------------------------
// DeduplicateStep (ConcretePrototype)
// ---------------------------------------------------------------------
DeduplicateStep::DeduplicateStep() : Transformation("dedup") {}

Transformation* DeduplicateStep::clone() {
    // Copy constructor only copies the (value-typed) name member, so
    // the clone shares no state with the prototype it came from.
    return new DeduplicateStep(*this);
}

std::vector<std::string> DeduplicateStep::apply(std::vector<std::string> records) {
    std::vector<std::string> result;
    for (size_t i = 0; i < records.size(); ++i) {
        if (result.empty() || result.back() != records[i]) {
            result.push_back(records[i]);
        }
    }
    return result;
}

// ---------------------------------------------------------------------
// AggregateByRegionStep (ConcretePrototype)
// ---------------------------------------------------------------------
AggregateByRegionStep::AggregateByRegionStep() : Transformation("aggregate") {}

Transformation* AggregateByRegionStep::clone() {
    return new AggregateByRegionStep(*this);
}

std::vector<std::string> AggregateByRegionStep::apply(std::vector<std::string> records) {
    return {"COUNT=" + std::to_string(records.size())};
}