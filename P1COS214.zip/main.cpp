#include <iostream>
#include <vector>
#include <string>

#include "PostgresFactory.h"
#include "RestApiFactory.h"
#include "CsvFactory.h"
#include "TransformationRegistry.h"
#include "Pipeline.h"
#include "RunCheckpoint.h"
#include "CheckpointManager.h"

// ============================================================
// This file is a TEST HARNESS covering Tasks 1-4. It is NOT the
// Task 5 submission main.cpp - keep that one separate for the
// actual hand-in.
// ============================================================

static int passed = 0;
static int failed = 0;

static void check(const std::string& label, bool condition) {
    if (condition) {
        std::cout << "  [PASS] " << label << std::endl;
        ++passed;
    } else {
        std::cout << "  [FAIL] " << label << std::endl;
        ++failed;
    }
}

static void printRecords(const std::string& label, const std::vector<std::string>& records) {
    std::cout << "  " << label << ": ";
    for (size_t i = 0; i < records.size(); ++i) {
        std::cout << records[i];
        if (i + 1 < records.size()) std::cout << ", ";
    }
    std::cout << std::endl;
}

// --- Task 1: Factory Method -----------------------------------------
void testFactoryMethod() {
    std::cout << "=== Task 1: Factory Method ===" << std::endl;

    struct Case { ConnectorFactory* factory; std::string expectedSource; std::string label; };
    std::vector<Case> cases = {
        {new PostgresFactory(), "postgres", "PostgresFactory"},
        {new RestApiFactory(),  "restapi",  "RestApiFactory"},
        {new CsvFactory(),      "csv",      "CsvFactory"}
    };

    for (auto& c : cases) {
        std::cout << c.label << ":" << std::endl;
        Connector* connector = c.factory->createConnector();
        check("source == \"" + c.expectedSource + "\"", connector->getSource() == c.expectedSource);
        printRecords("extracted", connector->extract());
        delete connector;
        delete c.factory;
    }
    std::cout << std::endl;
}

// --- Task 2: Prototype -----------------------------------------
void testPrototype() {
    std::cout << "=== Task 2: Prototype ===" << std::endl;

    TransformationRegistry registry;
    registry.registerStep("dedup", new DeduplicateStep());
    registry.registerStep("aggregate", new AggregateByRegionStep());

    Transformation* dedupA = registry.create("dedup");
    Transformation* dedupB = registry.create("dedup");
    check("two dedup clones are distinct objects", dedupA != dedupB);

    std::vector<std::string> dedupOut = dedupA->apply({"a", "a", "b", "a"});
    printRecords("dedup output", dedupOut);
    check("dedup output == {a,b,a}",
          dedupOut.size() == 3 && dedupOut[0] == "a" && dedupOut[1] == "b" && dedupOut[2] == "a");

    Transformation* aggregate = registry.create("aggregate");
    std::vector<std::string> aggOut = aggregate->apply({"x", "y", "z"});
    printRecords("aggregate output", aggOut);
    check("aggregate output == {COUNT=3}", aggOut.size() == 1 && aggOut[0] == "COUNT=3");

    registry.registerStep("dedup", new DeduplicateStep()); // overwrite, old one freed
    check("create(\"missing\") == nullptr", registry.create("missing") == nullptr);

    delete dedupA;
    delete dedupB;
    delete aggregate;
    std::cout << std::endl;
}

// --- Task 3: Template Method -----------------------------------------
void testTemplateMethod() {
    std::cout << "=== Task 3: Template Method ===" << std::endl;

    TransformationRegistry registry;
    registry.registerStep("dedup", new DeduplicateStep());
    registry.registerStep("aggregate", new AggregateByRegionStep());

    std::cout << "BatchPipeline:" << std::endl;
    Pipeline* batch = new BatchPipeline(new PostgresFactory());
    batch->addStep(registry.create("dedup"));
    batch->addStep(registry.create("aggregate"));
    batch->run();
    RunCheckpoint* batchCp = batch->createCheckpoint();
    check("BatchPipeline stage == 4 after run()", batchCp->getStage() == 4);
    check("BatchPipeline records == {COUNT=3} after dedup+aggregate",
          batchCp->getRecords().size() == 1 && batchCp->getRecords()[0] == "COUNT=3");
    delete batchCp;
    delete batch;

    std::cout << "StreamingPipeline:" << std::endl;
    Pipeline* streaming = new StreamingPipeline(new CsvFactory());
    streaming->run(); // no steps added - records should pass through untouched
    RunCheckpoint* streamCp = streaming->createCheckpoint();
    check("StreamingPipeline stage == 4 after run()", streamCp->getStage() == 4);
    check("StreamingPipeline records unchanged with no steps (4 raw CSV records)",
          streamCp->getRecords().size() == 4);
    delete streamCp;
    delete streaming;

    std::cout << std::endl;
}

// --- Task 4: Memento -----------------------------------------
void testMemento() {
    std::cout << "=== Task 4: Memento ===" << std::endl;

    TransformationRegistry registry;
    registry.registerStep("dedup", new DeduplicateStep());
    registry.registerStep("aggregate", new AggregateByRegionStep());

    CheckpointManager manager;
    check("undo() on empty manager returns nullptr", manager.undo() == nullptr);

    // "First run": completes, gets checkpointed and saved.
    Pipeline* run1 = new BatchPipeline(new PostgresFactory());
    run1->addStep(registry.create("dedup"));
    run1->addStep(registry.create("aggregate"));
    run1->run();
    manager.save(run1->createCheckpoint());
    delete run1;

    // "Crash + restart": a fresh pipeline restores from the last checkpoint.
    Pipeline* recovered = new BatchPipeline(new PostgresFactory());
    RunCheckpoint* last = manager.undo();
    check("undo() returns the saved checkpoint", last != nullptr);
    check("recovered checkpoint stage == 4", last->getStage() == 4);
    recovered->restore(last);
    check("second undo() is now empty", manager.undo() == nullptr);

    delete last;
    delete recovered;

    std::cout << std::endl;
}

int main() {
    testFactoryMethod();
    testPrototype();
    testTemplateMethod();
    testMemento();

    std::cout << "=== Summary: " << passed << " passed, " << failed << " failed ===" << std::endl;
    return failed == 0 ? 0 : 1;
}